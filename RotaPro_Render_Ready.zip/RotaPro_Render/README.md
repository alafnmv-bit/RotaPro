
## Publicação no Render

1. Conecte sua conta do Render ao GitHub.
2. Envie este projeto para um repositório GitHub.
3. No Render, use **New > Blueprint** e selecione o repositório.
4. O `render.yaml` configura o serviço Node e o PostgreSQL.
5. `DATABASE_URL` e `JWT_SECRET` são configurados pelo Render.
6. Execute `db/schema.sql` e `db/seed.sql` no PostgreSQL do Render após a criação do banco.
7. Promova seu usuário a administrador com: `UPDATE users SET role='admin' WHERE phone='SEU_TELEFONE';`

O plano gratuito pode ter limitações de uso/suspensão e essas condições podem mudar; confira os limites atuais no painel do Render.
